package com.utn.tp_spring_grupal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpSpringGrupalApplicationTests {

	@Test
	void contextLoads() {
	}

}
