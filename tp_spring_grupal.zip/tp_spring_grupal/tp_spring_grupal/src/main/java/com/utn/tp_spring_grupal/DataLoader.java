package com.utn.tp_spring_grupal;

import com.utn.tp_spring_grupal.entities.*;
import jakarta.persistence.EntityManager;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
public class DataLoader implements CommandLineRunner {

    private final EntityManager em;

    public DataLoader(EntityManager em) {
        this.em = em;
    }

    @Override
    @Transactional
    public void run(String... args) throws Exception {
        // Verificar si ya existen facturas para no duplicar datos en cada reinicio
        Long count = em.createQuery("SELECT COUNT(f) FROM FacturaVenta f", Long.class).getSingleResult();
        if (count > 0) {
            System.out.println("La base de datos ya contiene información. Omitiendo carga inicial.");
            return;
        }
        Date ahora = new Date();

        System.out.println("Inyectando datos de prueba para Reportes y API REST...");

        // 1. Crear Usuario base (Requerido por AuditoriaApp)
        Usuario usuarioAdmin = Usuario.builder()
                .usuario("admin")
                .clave("123456")
                .nombre("Juan")
                .apellido("Perez")
                .build();
        em.persist(usuarioAdmin);

        PuntoVenta puntoVenta = PuntoVenta.builder()
                .numero(1)
                .descripcion("Punto de Venta Centro")
                .tipoEmision("Factura Electrónica")
                .domicilioComercial("Av. San Martín 1000")
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(puntoVenta);

        CondicionIva condicionIva = CondicionIva.builder()
                .codigoAfip(1)
                .denominacion("IVA Responsable Inscripto")
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(condicionIva);

        // 2. RUBRO
        Rubro rubroElec = new Rubro();
        rubroElec.setCodigo(10);
        rubroElec.setDenominacion("Electrónica");
        rubroElec.setFechaAlta(ahora);
        rubroElec.setFechaModificacion(ahora);
        rubroElec.setUsuarioCarga(usuarioAdmin);
        rubroElec.setUsuarioModificacion(usuarioAdmin);
        em.persist(rubroElec);

        // 3. CLIENTE (Contacto, Domicilio, Cliente)
        Contacto contacto = new Contacto();
        contacto.setEmail("juanperez@mail.com");
        em.persist(contacto);

        Domicilio domicilio = Domicilio.builder()
                .nombreCalle("Belgrano")
                .numeroCalle("456")
                .build();
        em.persist(domicilio);

        Cliente cliente = Cliente.builder()
                .cuitCuil("20-28123456-7")
                .denominacion("Juan Perez")
                .contacto(contacto)
                .domicilio(domicilio)
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(cliente);

        // 4. MARCAS Y ARTÍCULOS
        Marca marcaLogi = Marca.builder()
                .codigo(101)
                .denominacion("Logitech")
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(marcaLogi);

        Marca marcaSam = Marca.builder()
                .codigo(102)
                .denominacion("Samsung")
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(marcaSam);

        Articulo artMouse = Articulo.builder()
                .codigo("ART-001")
                .denominacion("Mouse Inalámbrico")
                .marca(marcaLogi)
                .rubro(rubroElec) // Asignamos el rubro
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(artMouse);

        Articulo artMonitor = Articulo.builder()
                .codigo("ART-002")
                .denominacion("Monitor 24 Pulgadas")
                .marca(marcaSam)
                .rubro(rubroElec)
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(artMonitor); // Este artículo NO se facturará

        // 5. LISTAS DE PRECIO
        ListaPrecio listaPrecio = ListaPrecio.builder()
                .codigo("LP-MAY")
                .denominacion("Lista Mayorista")
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(listaPrecio);

        ListaPrecioArticulo precioMouse = ListaPrecioArticulo.builder()
                .listaPrecio(listaPrecio)
                .articulo(artMouse)
                .precioVenta(15000.0)
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(precioMouse);

        ListaPrecioArticulo precioMonitor = ListaPrecioArticulo.builder()
                .listaPrecio(listaPrecio)
                .articulo(artMonitor)
                .precioVenta(150000.0)
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .build();
        em.persist(precioMonitor);

        // 6. FACTURAS Y DETALLES
        // Factura 1: $30,000 (Medio Valor)
        FacturaVenta factura1 = FacturaVenta.builder()
                .numero(1001L)
                .fechaEmision(ahora)
                .puntoVenta(puntoVenta)
                .importeCobrado(30000.0)
                .importeSaldo(0.0)
                .importeTotal(30000.0)
                .condicionIva(condicionIva)
                .cae("73428917238912")
                .resultadoAfip("A")
                .estado("Emitida")
                .observaciones("Venta minorista")
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .detalles(new ArrayList<>())
                .build();

        FacturaVentaDetalle det1F1 = FacturaVentaDetalle.builder()
                .listaPrecioArticulo(precioMouse)
                .descripcion("Mouse Inalámbrico - Unidad 1")
                .cantidad(1.0)
                .precioUnitario(15000.0)
                .importeSubtotal(15000.0)
                .factura(factura1)
                .build();

        FacturaVentaDetalle det2F1 = FacturaVentaDetalle.builder()
                .listaPrecioArticulo(precioMouse)
                .descripcion("Mouse Inalámbrico - Unidad 2")
                .cantidad(1.0)
                .precioUnitario(15000.0)
                .importeSubtotal(15000.0)
                .factura(factura1)
                .build();

        factura1.getDetalles().add(det1F1);
        factura1.getDetalles().add(det2F1);
        em.persist(factura1);

        // Factura 2
        FacturaVenta factura2 = FacturaVenta.builder()
                .numero(1002L)
                .fechaEmision(ahora)
                .puntoVenta(puntoVenta)
                .condicionIva(condicionIva)
                .importeCobrado(90000.0)
                .importeSaldo(0.0)
                .importeTotal(90000.0)
                .cae("99887766554433")
                .resultadoAfip("A")
                .estado("Emitida")
                .observaciones("Venta mayorista")
                .fechaAlta(ahora)
                .fechaModificacion(ahora)
                .usuarioCarga(usuarioAdmin)
                .usuarioModificacion(usuarioAdmin)
                .detalles(new ArrayList<>())
                .build();

        FacturaVentaDetalle det1F2 = FacturaVentaDetalle.builder()
                .listaPrecioArticulo(precioMouse)
                .descripcion("Mouse Inalámbrico - Lote Mayorista")
                .cantidad(6.0)
                .precioUnitario(15000.0)
                .importeSubtotal(90000.0)
                .factura(factura2)
                .build();

        factura2.getDetalles().add(det1F2);
        em.persist(factura2);

        System.out.println("¡Datos de prueba cargados con éxito!");
    }
}