package com.utn.tp_spring_grupal.controllers;

import com.utn.tp_spring_grupal.DTOs.FacturaReporteDTO;
import com.utn.tp_spring_grupal.services.FacturaService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/api/facturas")
public class FacturaController {
    private final FacturaService facturaService;

    public FacturaController(FacturaService facturaService) {
        this.facturaService = facturaService;
    }

    @GetMapping
    public ResponseEntity<List<FacturaReporteDTO>> buscarFacturasFiltradas(
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date fechaDesde,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date fechaHasta,
            @RequestParam(required = false) String estado,
            @RequestParam(required = false) Double montoMinimo) {
        return ResponseEntity.ok(facturaService.buscarFacturasFiltradas(fechaDesde, fechaHasta, estado, montoMinimo));
    }

    @GetMapping("/generar-pdf")
    public ResponseEntity<String> probarGeneracionPdf() {
        // Obtenemos todas las facturas sin filtros para el reporte
        List<FacturaReporteDTO> datos = facturaService.buscarFacturasFiltradas(null, null, null, null);
        facturaService.generarReportePDF(datos, "reporte_ventas.pdf");
        return ResponseEntity.ok("Archivo PDF generado con éxito en la raíz del proyecto.");
    }

    @GetMapping("/generar-excel")
    public ResponseEntity<String> probarGeneracionExcel() {
        // Obtenemos todas las facturas sin filtros para el reporte
        List<FacturaReporteDTO> datos = facturaService.buscarFacturasFiltradas(null, null, null, null);
        facturaService.generarReporteExcelTxt(datos, "reporte_ventas.txt");
        return ResponseEntity.ok("Archivo TXT tabular generado con éxito en la raíz del proyecto. Listo para abrir con Excel.");
    }
}
