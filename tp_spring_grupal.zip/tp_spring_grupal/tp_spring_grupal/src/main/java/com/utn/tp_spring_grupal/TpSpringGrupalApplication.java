package com.utn.tp_spring_grupal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpSpringGrupalApplication {

	public static void main(String[] args) {
		SpringApplication.run(TpSpringGrupalApplication.class, args);
	}

}
