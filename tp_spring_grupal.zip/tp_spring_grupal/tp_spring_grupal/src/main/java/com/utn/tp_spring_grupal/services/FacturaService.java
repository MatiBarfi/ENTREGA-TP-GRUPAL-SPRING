package com.utn.tp_spring_grupal.services;

import com.utn.tp_spring_grupal.DTOs.FacturaReporteDTO;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.springframework.stereotype.Service;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class FacturaService {

    private final EntityManager em;

    public FacturaService(EntityManager em) {
        this.em = em;
    }

    // Ejecuta la consulta JPQL y devuelve la lista de DTOs
    public List<FacturaReporteDTO> buscarFacturasFiltradas(Date fechaDesde, Date
            fechaHasta, String estado, Double montoMinimo) {
        StringBuilder jpql = new StringBuilder(
                "SELECT new com.utn.tp_spring_grupal.DTOs.FacturaReporteDTO(" +
                        " f.numero, f.fechaEmision, COALESCE(c.denominacion, 'Consumidor Final'), " +
                        " ci.denominacion, pv.descripcion, f.importeTotal, COUNT(d)" +
                                ") " +
                                "FROM FacturaVenta f " +
                                "LEFT JOIN f.cliente c " +
                                "JOIN f.condicionIva ci " +
                                "JOIN f.puntoVenta pv " +
                                "JOIN f.detalles d " +
                                "WHERE 1=1 "
                );
        Map<String, Object> params = new HashMap<>();
        if (fechaDesde != null) {
            jpql.append("AND f.fechaEmision >= :fechaDesde ");
            params.put("fechaDesde", fechaDesde);
        }
        if (fechaHasta != null) {
            jpql.append("AND f.fechaEmision <= :fechaHasta ");
            params.put("fechaHasta", fechaHasta);
        }
        if (estado != null && !estado.trim().isEmpty()) {
            jpql.append("AND f.estado = :estado ");
            params.put("estado", estado);
        }
        if (montoMinimo != null) {
            jpql.append("AND f.importeTotal >= :montoMinimo ");
            params.put("montoMinimo", montoMinimo);
        }
        jpql.append("GROUP BY f.id, f.numero, f.fechaEmision, c.denominacion, ci.denominacion, pv.descripcion, f.importeTotal");
                TypedQuery<FacturaReporteDTO> query = em.createQuery(jpql.toString(),
                        FacturaReporteDTO.class);
        params.forEach(query::setParameter);
        return query.getResultList();
    }

    // Genera el archivo PDF usando iText
    public void generarReportePDF(List<FacturaReporteDTO> datos, String rutaDestino) {
        try {
            PdfWriter writer = new PdfWriter(rutaDestino);
            PdfDocument pdf = new PdfDocument(writer);
            Document document = new Document(pdf);

            document.add(new Paragraph("Reporte Ejecutivo de Ventas").setBold().setFontSize(16));
            document.add(new Paragraph(" ")); // Espacio

            // Crear tabla con 7 columnas
            Table table = new Table(new float[] { 1, 2, 3, 2, 2, 2, 1 });
            table.useAllAvailableWidth();

            // Encabezados
            String[] encabezados = { "Número", "Fecha", "Cliente", "Cond. IVA", "Pto. Venta", "Total", "Items" };
            for (String header : encabezados) {
                table.addHeaderCell(new Cell().add(new Paragraph(header).setBold()));
            }

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

            // Llenar datos
            for (FacturaReporteDTO dto : datos) {
                table.addCell(String.valueOf(dto.getNumeroFactura()));
                table.addCell(dto.getFechaEmision() != null ? sdf.format(dto.getFechaEmision()) : "");
                table.addCell(dto.getClienteDenominacion());
                table.addCell(dto.getCondicionIva());
                table.addCell(dto.getPuntoVentaDescripcion());
                table.addCell(String.format("$%.2f", dto.getImporteTotal()));
                table.addCell(String.valueOf(dto.getCantidadItems()));
            }

            document.add(table);
            document.close();
            System.out.println("PDF generado correctamente en: " + rutaDestino);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Genera un archivo TXT separado por tabulaciones (compatible con Excel)
    public void generarReporteExcelTxt(List<FacturaReporteDTO> datos, String rutaDestino) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(rutaDestino))) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

            // Escribir encabezados separados por tabulación (\t)
            pw.println(
                    "Número\tFecha de Emisión\tCliente\tCondición IVA\tPunto de Venta\tImporte Total\tCantidad de Ítems");

            // Escribir filas
            for (FacturaReporteDTO dto : datos) {
                String fecha = dto.getFechaEmision() != null ? sdf.format(dto.getFechaEmision()) : "";
                pw.printf("%d\t%s\t%s\t%s\t%s\t%.2f\t%d%n",
                        dto.getNumeroFactura(),
                        fecha,
                        dto.getClienteDenominacion(),
                        dto.getCondicionIva(),
                        dto.getPuntoVentaDescripcion(),
                        dto.getImporteTotal(),
                        dto.getCantidadItems());
            }
            System.out.println("Archivo Excel (TXT tabular) generado correctamente en: " + rutaDestino);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}